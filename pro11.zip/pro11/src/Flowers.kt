open class Flowers {
    //неазвание, тип, оттенок, страна-производитель, цена, длина стебля
    open var name:String=""
    open var type:String=""
    open var shade:String=""
    open var country_of_origin:String=""
    open var price:Double=0.0
    open protected var stem_length:Double=0.0
    open fun Info():String{
        return "name: $name\ntype: $type\nshade: $shade\ncountry of origin: $country_of_origin\nprice: $price\nstem length: $stem_length"
    }
    open fun Bouquet(n:Int):Double{
        return price*n
    }
    open fun Get_stem_length():Double{
        return stem_length
    }
    open fun Set_stem_length(new_stem_length: Double){
        stem_length=new_stem_length
    }
    open fun q1(rare_flower:Boolean):Double{
        if(rare_flower){
            return price*stem_length*1.6
        }
        else{
            return price*stem_length*0.7
        }
    }
}