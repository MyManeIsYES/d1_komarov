fun main()=try {
    var flowers_1=Flowers()
    flowers_1.name="просто цветок"
    flowers_1.type="типичный цветок"
    flowers_1.shade="цвет простой"
    flowers_1.country_of_origin="цветочный завод №3"
    flowers_1.price=199.9
    flowers_1.Set_stem_length(25.4)
    println(flowers_1.Info())
    print("n=")
    var n= readLine()!!.toInt()
    println("price bouquet: "+(flowers_1.Bouquet(n)))
    println("q1: "+String.format("%.2f",flowers_1.q1(true)))

    var tree_1=Tree()
    tree_1.name="простое дерево"
    tree_1.type="типичное дерево"
    tree_1.country_of_origin="цветочный завод №3"
    tree_1.price=1499.9
    tree_1.Set_stem_length(245.4)
    tree_1.Set_barrel_thickness(54.9)
    println(tree_1.Info())
    println("q1: "+String.format("%.2f",tree_1.q1(false)))



}
catch (e:NumberFormatException){println("error")}