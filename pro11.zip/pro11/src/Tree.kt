class Tree: Flowers() {
    override var name:String=""
    override var type:String=""
    override var country_of_origin:String=""
    override var price:Double=0.0
    override protected var stem_length:Double=0.0
    protected var barrel_thickness:Double=0.0
    override fun Info():String{
        return "name: $name\ntype: $type\ncountry of origin: $country_of_origin\nprice: $price\nstem length: $stem_length\nbarrel thickness: $barrel_thickness"
    }
    override fun Get_stem_length():Double{
        return stem_length
    }
    override fun Set_stem_length(new_stem_length: Double){
        stem_length=new_stem_length
    }
    fun Get_barrel_thickness():Double{
        return barrel_thickness
    }
    fun Set_barrel_thickness(new_barrel_thickness: Double){
        barrel_thickness=new_barrel_thickness
    }


    override fun q1(rare_tree:Boolean):Double{
        if(rare_tree){
            return price*stem_length*2.6
        }
        else{
            return price*stem_length*0.9
        }
    }
}